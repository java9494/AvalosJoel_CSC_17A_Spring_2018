/* 
 * File:   Player.h
 * Author: rcc
 * Purpose: Create a Player structure, for record keeping
 * Created on April 18, 2018, 10:46 AM
 */

#ifndef PLAYER_H
#define PLAYER_H
using namespace std;

struct Player{
    string name;//Name of the player
    GmeStat Scores;//Stats for player
    
};


#endif /* PLAYER_H */

