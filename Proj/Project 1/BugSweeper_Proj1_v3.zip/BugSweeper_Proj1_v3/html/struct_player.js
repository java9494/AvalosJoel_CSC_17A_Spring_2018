var struct_player =
[
    [ "name", "struct_player.html#acf0355128a99ee20ad9931b760fb2de1", null ],
    [ "Scores", "struct_player.html#ad3bbcf40156b9bb420ca9e8763fa7a5b", null ]
];