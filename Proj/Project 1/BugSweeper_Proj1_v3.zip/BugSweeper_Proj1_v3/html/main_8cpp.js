var main_8cpp =
[
    [ "bugTest", "main_8cpp.html#ac7399508c1e377458d6216a43c8a1dae", null ],
    [ "cleared", "main_8cpp.html#a8a52915f53329573b0fe418a4b75ba7a", null ],
    [ "dffclty", "main_8cpp.html#abdf1d5e1cccf87fd86cf07e6d881aaf5", null ],
    [ "display", "main_8cpp.html#afaf557d376c4471f5a4738170e860f12", null ],
    [ "exit", "main_8cpp.html#a358d2e2397ca11ccd17553e3c40e7901", null ],
    [ "game", "main_8cpp.html#a1bae1576554d6ec527663c79e98ae0f1", null ],
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "nbrBug", "main_8cpp.html#a8c354984247bdea5fcb3fa185b358f2e", null ],
    [ "nbrBugs", "main_8cpp.html#a8d60e4eea13b3eeec25871e27b8858ca", null ],
    [ "random", "main_8cpp.html#a2aea3e373c8cdc0cf36c69f1a8100f11", null ],
    [ "rules", "main_8cpp.html#a338ab9ba55fcf6f8ad764dc6f20cf6ca", null ],
    [ "savRecs", "main_8cpp.html#a9d681cbf7efccb7143cb5c71d27e45ca", null ],
    [ "scoreKp", "main_8cpp.html#a31f71484d6ceb6c6c045a1ae70d1bb0f", null ],
    [ "start", "main_8cpp.html#ab60d56e5bd4570f9c115e5227d5e250b", null ],
    [ "start", "main_8cpp.html#a2a212ccd41d6b32897c8c71bce77b9e3", null ],
    [ "COLS", "main_8cpp.html#abfdc2552f8ab882b4380b2a56cdff54f", null ],
    [ "COLS1", "main_8cpp.html#a2cc9d6742e0b7f9f0ab68704db31d96c", null ]
];