var struct_g_states =
[
    [ "gameLss", "struct_g_states.html#af6cd6c34da65324f19b7020595686281", null ],
    [ "gameWin", "struct_g_states.html#a48c29e2c2b79232ef5174465b2a8665b", null ],
    [ "scores", "struct_g_states.html#a8cf484a995ae032b5077397a071ee5cb", null ]
];