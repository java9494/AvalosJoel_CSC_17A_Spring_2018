var annotated_dup =
[
    [ "GmeGrid", "struct_gme_grid.html", "struct_gme_grid" ],
    [ "GmeStat", "struct_gme_stat.html", "struct_gme_stat" ],
    [ "GStates", "struct_g_states.html", "struct_g_states" ],
    [ "Player", "struct_player.html", "struct_player" ]
];