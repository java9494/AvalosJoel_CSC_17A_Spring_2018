var struct_gme_grid =
[
    [ "clrDsp", "struct_gme_grid.html#a4eb15bb45e302b3bc3ad17108bacf347", null ],
    [ "isitBug", "struct_gme_grid.html#ac5777a1adbc4318f9b1ffbf2493e1046", null ],
    [ "nbrBugs", "struct_gme_grid.html#a9bf7ade294e936efd7da7c058c82da2d", null ],
    [ "spots", "struct_gme_grid.html#a20203c469d9555ef5bf202d135ae4116", null ]
];