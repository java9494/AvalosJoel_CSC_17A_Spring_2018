var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "nbproject", "dir_2c333aeabd346f33518e235a93545ab3.html", "dir_2c333aeabd346f33518e235a93545ab3" ],
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "GmeGrid.h", "_gme_grid_8h.html", [
      [ "GmeGrid", "struct_gme_grid.html", "struct_gme_grid" ]
    ] ],
    [ "GmeStat.h", "_gme_stat_8h.html", [
      [ "GmeStat", "struct_gme_stat.html", "struct_gme_stat" ]
    ] ],
    [ "GStates.h", "_g_states_8h.html", [
      [ "GStates", "struct_g_states.html", "struct_g_states" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Player.h", "_player_8h.html", [
      [ "Player", "struct_player.html", "struct_player" ]
    ] ]
];