var struct_gme_stat =
[
    [ "pctLost", "struct_gme_stat.html#a381330d98723b7990209e8e9170b7e02", null ],
    [ "pctWon", "struct_gme_stat.html#a6d7bd3ec07c85e43f0d0d801645de16d", null ],
    [ "totGame", "struct_gme_stat.html#a782b9fb8694aa1bbded45914c26ffcd3", null ],
    [ "totLoss", "struct_gme_stat.html#ae7095273da851cc846b74d830c1d6009", null ],
    [ "totWon", "struct_gme_stat.html#a9c18dee97b01ea74985ca9fd5f34c573", null ]
];