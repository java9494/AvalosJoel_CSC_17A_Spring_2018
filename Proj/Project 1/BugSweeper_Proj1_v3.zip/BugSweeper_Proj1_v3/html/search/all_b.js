var searchData=
[
  ['totgame',['totGame',['../struct_gme_stat.html#a782b9fb8694aa1bbded45914c26ffcd3',1,'GmeStat']]],
  ['totloss',['totLoss',['../struct_gme_stat.html#ae7095273da851cc846b74d830c1d6009',1,'GmeStat']]],
  ['totwon',['totWon',['../struct_gme_stat.html#a9c18dee97b01ea74985ca9fd5f34c573',1,'GmeStat']]]
];
