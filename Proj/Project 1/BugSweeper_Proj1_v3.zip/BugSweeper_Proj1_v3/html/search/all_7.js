var searchData=
[
  ['name',['name',['../struct_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player']]],
  ['nbrbug',['nbrBug',['../main_8cpp.html#a8c354984247bdea5fcb3fa185b358f2e',1,'main.cpp']]],
  ['nbrbugs',['nbrBugs',['../struct_gme_grid.html#a9bf7ade294e936efd7da7c058c82da2d',1,'GmeGrid::nbrBugs()'],['../main_8cpp.html#a8d60e4eea13b3eeec25871e27b8858ca',1,'nbrBugs():&#160;main.cpp']]]
];
