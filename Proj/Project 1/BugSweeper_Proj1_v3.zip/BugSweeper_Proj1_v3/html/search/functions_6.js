var searchData=
[
  ['nbrbug',['nbrBug',['../main_8cpp.html#a8c354984247bdea5fcb3fa185b358f2e',1,'main.cpp']]],
  ['nbrbugs',['nbrBugs',['../main_8cpp.html#a8d60e4eea13b3eeec25871e27b8858ca',1,'main.cpp']]]
];
