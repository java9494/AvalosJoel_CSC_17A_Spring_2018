var searchData=
[
  ['savrecs',['savRecs',['../main_8cpp.html#a9d681cbf7efccb7143cb5c71d27e45ca',1,'main.cpp']]],
  ['scorekp',['scoreKp',['../main_8cpp.html#a31f71484d6ceb6c6c045a1ae70d1bb0f',1,'main.cpp']]],
  ['scores',['scores',['../struct_g_states.html#a8cf484a995ae032b5077397a071ee5cb',1,'GStates::scores()'],['../struct_player.html#ad3bbcf40156b9bb420ca9e8763fa7a5b',1,'Player::Scores()']]],
  ['spots',['spots',['../struct_gme_grid.html#a20203c469d9555ef5bf202d135ae4116',1,'GmeGrid']]],
  ['start',['start',['../main_8cpp.html#ab60d56e5bd4570f9c115e5227d5e250b',1,'start(string):&#160;main.cpp'],['../main_8cpp.html#a2a212ccd41d6b32897c8c71bce77b9e3',1,'start(GmeGrid [][COLS], int):&#160;main.cpp']]]
];
