var searchData=
[
  ['gamelss',['gameLss',['../struct_g_states.html#af6cd6c34da65324f19b7020595686281',1,'GStates']]],
  ['gamewin',['gameWin',['../struct_g_states.html#a48c29e2c2b79232ef5174465b2a8665b',1,'GStates']]]
];
