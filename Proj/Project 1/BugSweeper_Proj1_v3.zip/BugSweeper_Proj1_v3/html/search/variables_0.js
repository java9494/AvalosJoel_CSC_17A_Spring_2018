var searchData=
[
  ['clrdsp',['clrDsp',['../struct_gme_grid.html#a4eb15bb45e302b3bc3ad17108bacf347',1,'GmeGrid']]],
  ['cols',['COLS',['../main_8cpp.html#abfdc2552f8ab882b4380b2a56cdff54f',1,'main.cpp']]],
  ['cols1',['COLS1',['../main_8cpp.html#a2cc9d6742e0b7f9f0ab68704db31d96c',1,'main.cpp']]]
];
