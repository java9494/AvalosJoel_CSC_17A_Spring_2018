var searchData=
[
  ['cleared',['cleared',['../main_8cpp.html#a8a52915f53329573b0fe418a4b75ba7a',1,'main.cpp']]]
];
