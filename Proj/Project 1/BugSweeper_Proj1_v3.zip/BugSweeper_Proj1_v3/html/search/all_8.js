var searchData=
[
  ['pctlost',['pctLost',['../struct_gme_stat.html#a381330d98723b7990209e8e9170b7e02',1,'GmeStat']]],
  ['pctwon',['pctWon',['../struct_gme_stat.html#a6d7bd3ec07c85e43f0d0d801645de16d',1,'GmeStat']]],
  ['player',['Player',['../struct_player.html',1,'']]],
  ['player_2eh',['Player.h',['../_player_8h.html',1,'']]]
];
