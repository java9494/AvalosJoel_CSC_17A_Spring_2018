var searchData=
[
  ['name',['name',['../struct_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player']]],
  ['nbrbugs',['nbrBugs',['../struct_gme_grid.html#a9bf7ade294e936efd7da7c058c82da2d',1,'GmeGrid']]]
];
