var searchData=
[
  ['scores',['scores',['../struct_g_states.html#a8cf484a995ae032b5077397a071ee5cb',1,'GStates::scores()'],['../struct_player.html#ad3bbcf40156b9bb420ca9e8763fa7a5b',1,'Player::Scores()']]],
  ['spots',['spots',['../struct_gme_grid.html#a20203c469d9555ef5bf202d135ae4116',1,'GmeGrid']]]
];
