/* 
 * File:   Emplyee.h
 * Author: Joel Avalos
 * Purpose: Create Employee specifications
 * Created on March 31, 2018, 9:50 AM
 */

#include <iostream>

#include "Emplyee.h"