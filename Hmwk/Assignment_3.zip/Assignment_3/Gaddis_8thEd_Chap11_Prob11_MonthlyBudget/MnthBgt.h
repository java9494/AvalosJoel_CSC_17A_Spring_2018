/* 
 * File:   MnthBgt.h
 * Author: Joel
 * Purpose: Create a monthly budget structure.
 * Created on March 25, 2018, 10:28 AM
 */

#ifndef MNTHBGT_H
#define MNTHBGT_H
struct MnthBgt {
    float hsing,utility,hseStuf,trnsprt,food,medic,insrnce,
                   entrtn,clothes,misc;
};


#endif /* MNTHBGT_H */

